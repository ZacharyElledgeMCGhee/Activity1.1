package com.example.activity1;

public class View {
}
